<?php
//Conexion con la base
include 'Conexion.php';
 


//Creamos la sentencia SQL y la ejecutamos
$sql = "SELECT presidente FROM usuario WHERE idSocio='{$_POST["hidden1"]}'";

$sentencia = mysqli_query($conn,$sql);

$row=mysqli_fetch_array($sentencia);     



//COMPROBAR QUE EL UPDATE SE HA REALIZADO CORRECTAMENTE 
if ($row['presidente']==0) {
    $sql1="UPDATE usuario SET presidente=1 Where idSocio='{$_POST["hidden1"]}'";
    mysqli_query($conn,$sql1);
    header('Location: ../Socios_Admin.php');

} else if($row['presidente']==1){
    $sql2="UPDATE usuario SET presidente=0 Where idSocio='{$_POST["hidden1"]}'";
    mysqli_query($conn,$sql2);
    header('Location: ../Socios_Admin.php');
}

//CERRAR LA CONEXIÓN    
mysqli_close($conn);


?>