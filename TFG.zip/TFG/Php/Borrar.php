<?php
//Conexion con la base
include 'Conexion.php';
 


//Creamos la sentencia SQL y la ejecutamos
$sql="Delete From usuario Where idSocio='{$_POST["hidden1"]}'";
//COMPROBAR QUE EL DELETE SE HA REALIZADO CORRECTAMENTE
if (mysqli_query($conn,$sql)) {
    echo "<br> Registro Borrado correctamente";
    header('Location: ../Socios_Admin.php');
} else {
    echo "<br> Error al borrar datos en la base de datos";
}

//CERRAR LA CONEXIÓN    
mysqli_close($conn);


?>