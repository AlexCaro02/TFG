<?php
//Conexion con la base
include 'Conexion.php';
session_start();
 
//CREAMOS LA SENTENCIA SQL
$user=$_SESSION['usuario'];
$sql = "SELECT * FROM usuario WHERE usuario='".$user."'";

$sentencia = mysqli_query($conn,$sql);

$_SESSION['errorOldPass']="";
$_SESSION['errorNewPass']="";
$_SESSION['passCreated']="";

$row=mysqli_fetch_array($sentencia); 

$currentPass =$row['password'];

$oldPass="La contraseña es erronea";
$newPass="Las contraseñas no coinciden";
$newPassVoid="La contraseña debe ser al menos un caracter";
$passChanged="Contraseña cambiada correctamente";

//COMPROBAMOS EN LA BASE DE DATOS LA ANTIGUA CONTRASEÑA Y SI ES VERDAD 
//METEMOS LA NUEVA SI ESQUE LAS DOS SON IGUALES

if($_POST['oldPass']==$currentPass){

    if($_POST['newPass']!=""){

        if($_POST['newPass']==$_POST['newPassConfirm']){

            $passNew = $_POST['newPass'];
            $sql1="UPDATE usuario SET password='$passNew' Where usuario='".$user."'";
            $_SESSION['passCreated']=$passChanged;
            mysqli_query($conn,$sql1);
            header('Location: ../PerfilUsuario.php');

        }else{
            $_SESSION['errorNewPass']=$newPass;
            header('Location: ../PerfilUsuario.php');
        }

    }else{

        $_SESSION['errorNewPass']=$newPassVoid;
            header('Location: ../PerfilUsuario.php');

    }

}else{
    $_SESSION['errorOldPass']=$oldPass;
    header('Location: ../PerfilUsuario.php');
}

mysqli_close($conn);


?>