<?php
//AQUI SOLO CREAMOS LOS PARAMETROS DE LA BASE DE DATOS Y NOS CONECTAMOS
$server = "localhost";
$username = "root";
$password = "";
$database = "club"; 

$conn = mysqli_connect($server, $username, $password, "$database");
?>