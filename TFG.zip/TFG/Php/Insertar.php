<?php

include 'Conexion.php';

if(isset($_POST["botonreg"])){
 
$usuario = $_POST["usuario"];
$dni = $_POST["dni"];
$nombre = $_POST["nombre"];
$apellido = $_POST["apellido"];
$numfam = $_POST["numfam"];


//QUERY INSERTAR CON TODOS LOS DATOS
    $sql = "INSERT INTO usuario (usuario,dni,nombre,apellidos,numFamiliares)
    VALUES ('$usuario','$dni','$nombre','$apellido','$numfam')";


    //COMPROBAR QUE EL INSERT SE HA REALIZADO CORRECTAMENTE Y INSERTAR
    if (mysqli_query($conn,$sql)) {
        echo "<br> Registro creado correctamente";
    } else {
        echo "<br> Error al insertar datos en la base de datos";
    }

    //CERRAR LA CONEXIÓN    
mysqli_close($conn);

}
?>