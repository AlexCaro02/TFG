<?php
//Conexion con la base
session_start();
include './Php/Conexion.php';

//INICIALIZAMOS VARIABLES

$opcError = $fechaError = $sociosError = $sociosError = $invitadosError= $horaError = "";
$_SESSION['sociosError']="";
$_SESSION['invitadosError']="";
$_SESSION['invitadosAlquilerError']="";
$_SESSION['sociosAlquilerError']="";

//HACEMOS ALGUNAS COMPROBACIONES DE LOS DATOS INTRODUCIDOS Y REDIRIGIMOS
 
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $cont = 0; 
    if($_SESSION["fechaAlquiler"]==""){
      $fechaError = "La fecha debe de estar seleccionada";
      $_SESSION['fechaAlquilerError']=$fechaError;
      $_SESSION['fechaAlquiler']="";
      $_SESSION['opcAlquiler']="";
      $_SESSION['opcAlquilerid']="";
      $_SESSION['horaAlquilerid']="";
      $cont++;
    }
    if($_SESSION["opcAlquiler"] == ""){
      $opcError = "Eligue una opcion";
      $_SESSION['opcAlquilerError']=$opcError;
      $_SESSION['fechaAlquiler']="";
      $_SESSION['opcAlquiler']="";
      $_SESSION['opcAlquilerid']="";
      $_SESSION['horaAlquilerid']="";
      $cont++; 
    }
    if(isset($_POST["hora"])){
        
      }else{
        $horaError = "Eligue una hora";
        $_SESSION['horaAlquilerError']=$horaError;
        $_SESSION['fechaAlquiler']="";
        $_SESSION['opcAlquiler']="";
        $_SESSION['opcAlquilerid']="";
        $_SESSION['horaAlquilerid']="";
        $cont++; 
      }
    if($_POST["socios"]==""){
        $sociosError = "Introduzca el numero de socios";
        $_SESSION['sociosAlquilerError']=$sociosError;
        $_SESSION['fechaAlquiler']="";
        $_SESSION['opcAlquiler']="";
        $_SESSION['opcAlquilerid']="";
        $_SESSION['horaAlquilerid']="";
        $cont++; 
        }
    if($_POST["socios"]==0){
          $sociosError = "Introduzca al menos un socio";
          $_SESSION['sociosAlquilerError']=$sociosError;
          $_SESSION['fechaAlquiler']="";
          $_SESSION['opcAlquiler']="";
          $_SESSION['opcAlquilerid']="";
          $_SESSION['horaAlquilerid']="";
          $cont++; 
          }
    if($_POST["invitados"]==""){
        $sociosError = "Introduzca el numero de invitados";
        $_SESSION['invitadosAlquilerError']=$sociosError;
        $_SESSION['fechaAlquiler']="";
        $_SESSION['opcAlquiler']="";
        $_SESSION['opcAlquilerid']="";
        $_SESSION['horaAlquilerid']="";
        $cont++; 
        }
    if($cont == 0){
        
        $_SESSION['hora'] = $_POST["hora"];
        $_SESSION['socios'] = $_POST["socios"];
        $_SESSION['invitados'] = $_POST["invitados"];
        
        header('Location: Confirmar_Comprar_Usuario.php');

    }else{
      header('Location: Alquiler_Usuario.php');
    }
    echo $cont;
}


//CERRAR LA CONEXIÓN    
mysqli_close($conn);


?>