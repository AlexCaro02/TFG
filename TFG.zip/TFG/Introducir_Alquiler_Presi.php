<?php
//Conexion con la base
session_start();
include './Php/Conexion.php';

//TRAEMOS LAS VARIABLES
 
$idServicio=$_SESSION['opcAlquilerid'];

$fecha=$_SESSION["fechaAlquiler"];
$horas=$_SESSION["hora"];
$socios=$_SESSION['socios'];
$invitados=$_SESSION['invitados'];
$precioTotal=$_SESSION['precioTotal'];

$idSocio=0;
$sql2 = "SELECT * FROM usuario WHERE usuario='".$_SESSION['usuario']."';";
$ejecuta_sentencia2 = mysqli_query($conn, $sql2);
while ($row2 = mysqli_fetch_array($ejecuta_sentencia2)) {
    $idSocio=$row2['idSocio'];
}



//QUERY INSERTAR CON TODOS LOS DATOS
$sql = "INSERT INTO alquiler (idServicio,idSocio,fecha,horas,personaSocio,personaNoSocio,precio)
VALUES ('$idServicio','$idSocio','$fecha','$horas','$socios','$invitados','$precioTotal')";
//COMPROBAR QUE EL INSERT SE HA REALIZADO CORRECTAMENTE Y INSERTAR
if (mysqli_query($conn,$sql)) {
    $_SESSION['compraRealizada'] = "<br> Compra realizada correctamente";

  header('Location: Alquiler_Presi.php');


} else {
  $correcto = "<br> Error al insertar datos en la base de datos";
}


//CERRAR LA CONEXIÓN    
mysqli_close($conn);


?>