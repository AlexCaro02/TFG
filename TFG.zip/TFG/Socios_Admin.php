<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesion</title>
    <link rel="stylesheet" href="Css.css" />
    <link href="fontawesome/css/all.css" rel="stylesheet" />
</head>
<body>
<?php
session_start(); 
include './Php/Conexion.php';
?>
    <div id="header">
        <div class="logito">
        <img src="SocialClub (2).svg" alt="Logo_Social_Club" class="logo" />
        </div>
        <nav>
            <a href="Principal_Admin.php">Home</a>
            <a href="Noticias_admin.php">Noticias</a>
            <a href="Facturas_Admin.php">Facturas</a>
            <a href="Socios_Admin.php">Socios</a>
            <div class="animation start-4"></div>
        </nav>
        <!-- DESTRUIMOS LA SESION -->
        <form action='destruir_sesion.php' class="Sesions">
            <label for="sesionDestroy" class="nombreUsuario"><?php echo $_SESSION['usuario'];?></label>
            <input type="submit" name="sesionDestroy" value="CERRAR" class="cerraSesion"/>
        </form>

    </div>
<!-- MOSTRAMOS LOS USUARIOS Y EL ADMIN PODRA MODIFICAR CIERTAS COSAS EN ELLOS -->
        <table class="container">
            <tr>
                <th>Usuario</th>
                <th>Password</th>
                <th>DNI</th>
                <th>Presidente</th>
                <th>Activar</th>
                <th>Activar Presidente</th>
                <th>Borrar</th>
                
                <?php

                        $sql= "SELECT * FROM usuario WHERE usuario <> 'admin'";
                        $ejecuta_sentencia = mysqli_query($conn, $sql);

                        while($row=mysqli_fetch_array($ejecuta_sentencia)) {                              
                            echo"<tr>";
                            echo"<td>".$row['usuario']."</td>";
                            echo"<td>";
                            if($row['password']!=""){echo "activado";}else{
                              echo "desactivado";
                            }
                            echo "</td>";
                            echo"<td>".$row['dni']."</td>";
                            echo"<td>";
                            if($row['presidente']==1){echo "activado";}else{
                              echo "desactivado";
                            }
                            echo "</td>";

                            

                            echo"<td><form method='POST' action='./Php/Activar_Usuario.php'><input type='hidden' name='hidden1' value='".$row['idSocio']."'/>
                                                                                    <input type='submit' value='Activar'/></form></td>";
                            echo"<td><form method='POST' action='./Php/Activar_Presi.php'><input type='hidden' name='hidden1' value='".$row['idSocio']."'/>
                                                                                    <input type='submit' value='Activar Presi'/></form></td>";
                            echo"<td><form method='POST' action='./Php/Borrar.php'><input type='hidden' name='hidden1' value='".$row['idSocio']."'/>
                                                                                    <input type='submit' value='Borrar'/></form></td>";
                            
                            echo"</tr>";
                        }

                    ?>

            <tr>
        </table>
        
        <footer>
      <br>
      <div class="Terminos">
        <div class="Politica">
            <ul>
              <li>Política de privacidad</li>
              <li> | </li>
              <li>Política de cookies</li>
              <li> | </li>
              <li>Contactos</li>
            </ul>
        </div>
        <div class="contendorfooterlogo">
          <img src="SocialClub (2).svg" alt="Logo_Social_Club" class="footerlogo" />
        </div>
        <div class="Propietarios">
          © By Alejandro
        </div>
      </div>
    </footer>
    </body>
</html>

