<!DOCTYPE html>
<html lang="en"> 

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Alquiler</title>
  <link rel="stylesheet" href="Css.css" />
  <link href="fontawesome/css/all.css" rel="stylesheet" />
  <link rel="stylesheet" href="calendario.css">
</head>

<body>
  <?php
  session_start();
  include './Php/Conexion.php';
  ?>
  <div id="header">
    <div class="logito">
      <img src="SocialClub (2).svg" alt="Logo_Social_Club" class="logo" />
    </div>
    <nav>
      <a href="Principal_Usuario.php">Home</a>
      <a href="Noticias.php">Noticias</a>
      <a href="Alquiler_Usuario.php">Alquilar</a>
      <a href="PerfilUsuario.php">Perfil</a>
      <div class="animation start-3"></div>
    </nav>
     <!-- DESTRUIMOS SESION-->
    <form action='destruir_sesion.php' class="Sesions">
      <label for="sesionDestroy" class="nombreUsuario"><?php echo $_SESSION['usuario']; ?></label>
      <input type="submit" name="sesionDestroy" value="CERRAR" class="cerraSesion" />
    </form>
  </div>
  <span class="valid-feedback"><?php echo $_SESSION['compraRealizada'];$_SESSION['compraRealizada']=""; ?></span>
  <span class="error invalid-feedback"><?php echo $_SESSION['fechaAlquilerError']; ?></span>
  <div class="contenedorAlquiler">
    <div class="cuerpoAlquilar">
      <div class="calendar" id="calendar">

      </div>
    </div>
    <!-- ELEGIMOS EL SERVICIO A ALQUILAR-->
    <div class="infoAlquiler">
      <div class="tipoAlquiler">
        <span class="error invalid-feedback"><?php echo $_SESSION['opcAlquilerError']; ?></span>
        <select name="servicios" id="servicios">
          <?php
           //PREGUNTAMOS A LA BASE DE DATOS LOS SERVICIOS
            echo"<option value='default' id='default'>Seleccione un servicio</option>";
          $sql = "SELECT * FROM servicios";
          $ejecuta_sentencia = mysqli_query($conn, $sql);

          while ($row = mysqli_fetch_array($ejecuta_sentencia)) {
            echo "<option value='".$row['servicio']."'name='".$row['servicio']."' id=".$row['idServicio'].">".$row['servicio']."</option>";
          }
          ?>
        </select>
        <div>
          <!-- ENVIAMOS A VALIDAR LOS DATOS-->
        <form action="validacion_Alquiler_Usuario.php" method="post">
          <input class="ocult" type="text" name="fechOcult" id="fehcOcult"/>
          <input class="ocult" type="text" name="opcOcult" id="opcOcult"/>
          <input class="ocult" type="text" name="opcOcultid" id="opcOcultid"/>
          <input type="submit" value="Consultar" class="consultar">

        </form>
      </div>
      </div>
      <div class="divTabla">
      <span class="error invalid-feedback"><?php echo $_SESSION['horaAlquilerError']; ?></span>
        <table class="container">
          <tr>
            <th colspan="2">Horario : <br><?php echo $_SESSION['fechaAlquiler']."<br>".$_SESSION['opcAlquiler']; ?></th>
          </tr>  
        <form action="validacion_Alquiler_Usuario2.php" method="post">
          <?php
          $sql2 = "SELECT * FROM alquiler WHERE fecha='".$_SESSION['fechaAlquiler']."' AND idServicio='".$_SESSION['opcAlquilerid']."';";
          $ejecuta_sentencia2 = mysqli_query($conn, $sql2);
          $arrayhoras = array();

          //SACAMOS LAS HORAS QUE SEAN DEL DIA QUE HEMOS ELEGIDO

          while ($row2 = mysqli_fetch_array($ejecuta_sentencia2)) {
            array_push($arrayhoras,$row2['horas']);
          }
          $hora1=0;
          $hora2=0;
          $hora3=0;
          $hora4=0;
          if(isset($arrayhoras[0])){
            if($arrayhoras[0]=="9:00 / 11:00"){
              $hora1++;
            }else if($arrayhoras[0]=="11:00 / 13:00"){
              $hora2++;
            }else if($arrayhoras[0]=="17:00 / 19:00"){
              $hora3++;
            }else if($arrayhoras[0]=="19:00 / 21:00"){
              $hora4++;
            }
          }
          if(isset($arrayhoras[1])){
            if($arrayhoras[1]=="9:00 / 11:00"){
              $hora1++;
            }else if($arrayhoras[1]=="11:00 / 13:00"){
              $hora2++;
            }else if($arrayhoras[1]=="17:00 / 19:00"){
              $hora3++;
            }else if($arrayhoras[1]=="19:00 / 21:00"){
              $hora4++;
            }
          }
          if(isset($arrayhoras[2])){
            if($arrayhoras[2]=="9:00 / 11:00"){
            $hora1++;
            }else if($arrayhoras[2]=="11:00 / 13:00"){
              $hora2++;
            }else if($arrayhoras[2]=="17:00 / 19:00"){
              $hora3++;
            }else if($arrayhoras[2]=="19:00 / 21:00"){
              $hora4++;
            }
          }
          if(isset($arrayhoras[3])){
            if($arrayhoras[3]=="9:00 / 11:00"){
              $hora1++;
            }else if($arrayhoras[3]=="11:00 / 13:00"){
              $hora2++;
            }else if($arrayhoras[3]=="17:00 / 19:00"){
              $hora3++;
            }else if($arrayhoras[3]=="19:00 / 21:00"){
              $hora4++;
            }
            if(isset($arrayhoras[0])&&isset($arrayhoras[1])&&isset($arrayhoras[2])&&isset($arrayhoras[3])){
              echo "<span class='error invalid-feedback'>No hay horas en este dia</span>";
            }
          }

          if($hora1==0){
            echo "<tr>
            <td class='tdradio'><input name='hora' value='9:00 / 11:00' type='radio'></td>
            <td>9:00 / 11:00</td>
          </tr>";
          }
          if($hora2==0){
            echo "<tr>
            <td class='tdradio'><input name='hora' value='11:00 / 13:00' type='radio'></td>
            <td>11:00 / 13:00</td>
          </tr>";
          }
          if($hora3==0){
            echo "<tr>
            <td class='tdradio'><input name='hora' value='17:00 / 19:00' type='radio'></td>
            <td>17:00 / 19:00</td>
          </tr>";
          }
          if($hora4==0){
            echo "<tr>
            <td class='tdradio'><input name='hora' value='19:00 / 21:00' type='radio'></td>
            <td>19:00 / 21:00</td>
          </tr>";
          }

          ?>

        </table>
      </div>
    </div>
     <!-- INDICAMOS LOS SOCIOS Y NO SOCIOS-->
    <div class="inputAlquiler">
      <span class="error invalid-feedback"><?php echo $_SESSION['sociosAlquilerError']; ?></span>
      <label for="Socios">Socios :</label><input type="number" value="0" name="socios" id="socios">
      <span class="error invalid-feedback"><?php echo $_SESSION['invitadosAlquilerError']; ?></span>
      <label for="Invitados">Invitados :</label><input type="number" value="0" name="invitados" id="invitados">
    </div>

    </div>
    <div class="contenedorBoton">
      <input type="submit" value="Alquilar" id="alquilar">
    </div>
  </form>
  <footer>
    <br>
    <div class="Terminos">
      <div class="Politica">
        <ul>
          <li>Política de privacidad</li>
          <li> | </li>
          <li>Política de cookies</li>
          <li> | </li>
          <li>Contactos</li>
        </ul>
      </div>
      
        <div class="contendorfooterlogo">
        <img src="SocialClub (2).svg" alt="Logo_Social_Club" class="footerlogo" />
      </div>
      <div class="Propietarios">
        © By Alejandro
      </div>
    </div>
  </footer>
</body>
</html>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/locale/es.js"></script>
  <script type="text/javascript" src="js.js"></script>
  <script type="text/javascript">
    //MOSTRAR CALENDARIO
    let calendar = new Calendar('calendar');
    calendar.getElement().addEventListener('change', e => {
      console.log(calendar.value().format('LLL'));
      var fecha = calendar.value().format('LLL');
      fecha = fecha.split('de');
      fecha[2] = fecha[2].slice(1, 5);
      document.getElementById('fehcOcult').value = fecha;
    });

// dividir la fecha con barras
    document.getElementById("servicios").addEventListener("change", myFunction);

    function myFunction() {
      var x = document.getElementById("servicios");
      document.getElementById("opcOcult").value=x.value;
      document.getElementById("opcOcultid").value=document.getElementsByName(x.value)[0].id;
    }

  </script>