<?php
//Conexion con la base
session_start();
include './Php/Conexion.php';
//INICIALIZAMOS VARIABLES

$fechaError = $opcError = "";
$_SESSION['fechaAlquilerError']="";
$_SESSION['opcAlquilerError']="";

//HACEMOS ALGUNAS COMPROBACIONES DE LOS DATOS INTRODUCIDOS Y REDIRIGIMOS

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $cont = 0;  
    if(empty($_POST["fechOcult"])){
      $fechaError = "La fecha debe de estar seleccionada";
      $_SESSION['fechaAlquilerError']=$fechaError;
      $_SESSION['fechaAlquiler']="";
      $_SESSION['opcAlquiler']="";
      $_SESSION['opcAlquilerid']="";
      $cont++;
    }
    if($_POST["opcOcult"] == null){
      $opcError = "Eligue una opcion";
      $_SESSION['opcAlquilerError']=$opcError;
      $_SESSION['fechaAlquiler']="";
      $_SESSION['opcAlquiler']="";
      $_SESSION['opcAlquilerid']="";
      $cont++; 
    }
    if($cont == 0){
        
        $_SESSION['fechaAlquiler']=$_POST["fechOcult"];
        $_SESSION['opcAlquiler']=$_POST["opcOcult"];
        $_SESSION['opcAlquilerid']=$_POST["opcOcultid"];


        header('Location: Alquiler_Presi.php');

    }else{
      header('Location: Alquiler_Presi.php');
    }
    echo $cont;
}


//CERRAR LA CONEXIÓN    
mysqli_close($conn);


?>