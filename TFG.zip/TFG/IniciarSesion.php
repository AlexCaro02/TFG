<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesion</title> 
    <link rel="stylesheet" href="Css.css" />
    <link href="fontawesome/css/all.css" rel="stylesheet" />
</head>
<body>

<?php
//INCLUIMOS LA CONEXION
include './Php/Conexion.php';
//INICIALIZAMOS LAS VARIABLES
$usuarioError = $contraseñaError = "";
$usuario = $contraseña = "";
$Error = "";
$rol = "";
//HACEMOS VALIDACIONES
if($_SERVER["REQUEST_METHOD"] == "POST"){
  $cont = 0; 
  if(empty($_POST["usuario"])){
    $usuarioError = "El usuario no puede estar vacio"; 
    $cont++;
  }else{
    
        $regexp = '/^[a-z0-9]+$/i';
        $entrada = $_POST["usuario"];

        $resultado = preg_match($regexp, $entrada);
        if(!$resultado) {
          $usuarioError = "El usuario no puede contener caracteres extraños"; 
        }

        $resultado = preg_match($regexp, $entrada);
        if($resultado) {
          $usuario = validar_input($_POST["usuario"]);
        }

  }
  if(empty($_POST["contraseña"])){
    $contraseñaError = "La contraseña no puede estar vacia";
    $cont++; 
  }else{
    $contraseña = validar_input($_POST["contraseña"]);
  }
  $q1 = mysqli_query($conn,"SELECT * FROM usuario WHERE usuario = '$usuario' AND password = '$contraseña';");
  if(mysqli_num_rows($q1) == 1){
    $usuario = validar_input($_POST["usuario"]);
    $contraseña = validar_input($_POST["contraseña"]);
  }else{
    $Error = "El usuario o contraseña es erronea";
    $cont++;
  }
  //*****************  INICIO SESION  ********************/

  //CONTROLAMOS SI EL USUARIO TIENE UN ROL O OTRO Y INICIALIZAMOS TODAS LAS SESIONES QUE NOS HARAN FALTA 
  if($cont == 0){
      echo "No hay errores";
      session_start();
      $_SESSION['usuario'] = $_POST["usuario"];
      $qAdmin = mysqli_query($conn,"SELECT * FROM usuario WHERE usuario = '$usuario' AND password = '$contraseña' AND admin = 1;");
      $qPresidente = mysqli_query($conn,"SELECT * FROM usuario WHERE usuario = '$usuario' AND password = '$contraseña' AND presidente = 1;");
    if(mysqli_num_rows($qAdmin) == 1){
      $rol="admin";
      $_SESSION['rol'] = $rol;
      $_SESSION['errorOldPass']="";
      $_SESSION['errorNewPass']="";
      $_SESSION['passCreated']="";
      $_SESSION['fechaAlquiler']="";
      $_SESSION['opcAlquiler']="";
      $_SESSION['opcAlquilerError']="";
      $_SESSION['fechaAlquilerError']="";
      $_SESSION["opcAlquilerid"]="";
      $_SESSION['horaAlquilerError']="";
      $_SESSION['sociosAlquilerError']="";
      $_SESSION['invitadosAlquilerError']="";
      $_SESSION['invitados']="";
      $_SESSION['socios']="";
      $_SESSION['hora']="";
      $_SESSION['precioTotal']="";
      $_SESSION['compraRealizada'] = "";
      header('Location: Principal_Admin.php');
    }elseif(mysqli_num_rows($qPresidente) == 1){
      $rol="presidente";
      $_SESSION['rol'] = $rol;
      $_SESSION['errorOldPass']="";
      $_SESSION['errorNewPass']="";
      $_SESSION['passCreated']="";
      $_SESSION['fechaAlquiler']="";
      $_SESSION['opcAlquiler']="";
      $_SESSION['opcAlquilerError']="";
      $_SESSION['fechaAlquilerError']="";
      $_SESSION["opcAlquilerid"]="";
      $_SESSION['horaAlquilerError']="";
      $_SESSION['sociosAlquilerError']="";
      $_SESSION['invitadosAlquilerError']="";
      $_SESSION['invitados']="";
      $_SESSION['socios']="";
      $_SESSION['hora']="";
      $_SESSION['precioTotal']="";
      $_SESSION['compraRealizada'] = "";
      header('Location: Principal_Presidente.php');
    }else{
      $rol="usuario";
      $_SESSION['rol'] = $rol;
      $_SESSION['errorOldPass']="";
      $_SESSION['errorNewPass']="";
      $_SESSION['passCreated']="";
      $_SESSION['fechaAlquiler']="";
      $_SESSION['opcAlquiler']="";
      $_SESSION['opcAlquilerError']="";
      $_SESSION['fechaAlquilerError']="";
      $_SESSION["opcAlquilerid"]="";
      $_SESSION['horaAlquilerError']="";
      $_SESSION['sociosAlquilerError']="";
      $_SESSION['invitadosAlquilerError']="";
      $_SESSION['invitados']="";
      $_SESSION['socios']="";
      $_SESSION['hora']="";
      $_SESSION['precioTotal']="";
      $_SESSION['compraRealizada'] = "";
      header('Location: Principal_Usuario.php');
    }




  }else{
  }
    //CERRAR LA CONEXIÓN    
    mysqli_close($conn);
}
//VALIDAMOS LOS INPUTS EN BUSCA DE SIMBOLOS EXTRAÑOS
function validar_input($data){
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>
<div class="conjunto">
    <div id="header">
        <img src="SocialClub (2).svg" alt="Logo_Social_Club" class="logo" />
    </div>
    <div class="cuenta">
        <div id="secundario">
            <div class="secundario_ini">

            
           <h1 class="titulo">Inicio de sesión</h1>
           <div class="textos">
                <form method="post" class="formIni"action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) ?>">
                    <input type="text" placeholder="Nombre de usuario" name="usuario" value="<?php if (!empty($_POST["usuario"])) {
                                                                                        echo $usuario; 
                                                                                      }else{
                                                                                        echo "";
                                                                                      }
                                                                                ?>"/>
                        <span class="error invalid-feedback"> <?php echo $usuarioError;?></span>
                    <input type="password" placeholder="Contraseña" name="contraseña" value="<?php if (!empty($_POST["contraseña"])) {
                                                                                        echo $contraseña; 
                                                                                      }else{
                                                                                        echo "";
                                                                                      }
                                                                                ?>"/>
                    <span class="error invalid-feedback"> <?php echo $contraseñaError;?></span>
            </div>
            <br />
            <div class="inicio">
                <input type="submit" id="botonini" value="Iniciar Sesion"/>
            </div>
            <br>
            <span class="error invalid-feedback"> <?php echo $Error;?></span>
          </form>
          </div>
        </div>
    </div>
    <div class="botonatras">
      <button class="atras"><a href="Home.php">Atrás</a></button> 
    </div>                                                                           
</div>
</body>

</html>