<!DOCTYPE html>
<html lang="en"> 
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Home</title>
    <link rel="stylesheet" href="Css.css" />
    <link href="fontawesome/css/all.css" rel="stylesheet" />
  </head>

  <body>
    <div class="conjunto">
      <div id="header">
        <img src="SocialClub (2).svg" alt="Logo_Social_Club" class="logo" />
      </div>
      <div class="ocultar1">
        <div id="container">
          <div class="redes">
            <div class="redes1">
              <i class="fab fa-google"></i><a href=""></a>
            </div>
            <div class="redes2">
              <i class="fab fa-facebook-f"></i><a href=""></a>
            </div>
            <div class="redes3">
              <i class="fab fa-twitter"></i><a href=""></a>
            </div>
          </div>

          <div class="cuerpo">
            <h1>
              <span> Entrena ,</span>
              <span> Disfruta </span>
              <br/>
              <span> <span class="y"> & </span> Socializa </span>
            </h1>
          </div>
          <br />
          <br />
          <br />
          <br />
<!-- BOTONES PARA IR A DISTINTOS LUGARES DE LA PAGINA -->
          <div class="contenedor_botones_principal">
            <div class="contenedor_botones">
              <button id="boton1" onclick="location.href='IniciarSesion.php'">Iniciar</button>
              <button id="boton2" onclick="location.href='Invitado.php'">Invitado</button>
              <button id="boton2" onclick="location.href='Registro.php'">Registrar</button>
              
            </div>
            
          </div>
        </div>
      </div>
    </div>
    <footer>
      <br>
      <div class="Terminos">
        <div class="Politica">
            <ul>
              <li>Política de privacidad</li>
              <li> | </li>
              <li>Política de cookies</li>
              <li> | </li>
              <li>Contactos</li>
            </ul>
        </div>
        <div class="contendorfooterlogo">
          <img src="SocialClub (2).svg" alt="Logo_Social_Club" class="footerlogo" />
        </div>
        <div class="Propietarios">
          © By Alejandro
        </div>
      </div>
    </footer>
  </body>
</html>
