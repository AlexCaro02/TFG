<!DOCTYPE html>
<html lang="en">
 
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Alquiler</title>
  <link rel="stylesheet" href="Css.css" />
  <link href="fontawesome/css/all.css" rel="stylesheet" />
  <link rel="stylesheet" href="calendario.css">
</head>

<body>
  <?php
  session_start();
  include './Php/Conexion.php';
  ?>
  <div id="header">
    <div class="logito">
      <img src="SocialClub (2).svg" alt="Logo_Social_Club" class="logo" />
    </div>
    <nav>
      <a href="Principal_Usuario.php">Home</a>
      <a href="Noticias.php">Noticias</a>
      <a href="Alquiler_Usuario.php">Alquilar</a>
      <a href="PerfilUsuario.php">Perfil</a>
      <div class="animation start-3"></div>
    </nav>
     <!-- DESTRUIR LA SESION -->
    <form action='destruir_sesion.php' class="Sesions">
      <label for="sesionDestroy" class="nombreUsuario"><?php echo $_SESSION['usuario']; ?></label>
      <input type="submit" name="sesionDestroy" value="CERRAR" class="cerraSesion" />
    </form>
  </div>
    <!-- PILLAMOS LAS VARIABLES NECESARIAS PARA PODER MOSTRARLE EL PRECIO DE TODO Y QUE NOS CONFIRME -->
 <div class="confirm">
    <p><?php echo "Servicio: ".$_SESSION['opcAlquiler']."<br> Fecha: ".$_SESSION["fechaAlquiler"]."<br> Hora: ".$_SESSION["hora"]."<br> Socios: ".$_SESSION['socios']."<br> Invitados: ".$_SESSION['invitados']; ?></p> 
    <br>
    <?php
          $sqlPrecio = "SELECT * FROM servicios WHERE servicio='".$_SESSION['opcAlquiler']."'";
          $ejecuta_sentencia_Precio = mysqli_query($conn, $sqlPrecio);
            $precioSocio=0;
            $precioNoSocio=0;
            $precioTotal=0;
          while ($rowPrecio = mysqli_fetch_array($ejecuta_sentencia_Precio)) {
            $precioSocio = $rowPrecio["precio_socio"];
            $precioNoSocio = $rowPrecio["precio_no_socio"];
          }
         $precioTotal = ($precioSocio*$_SESSION['socios'])+($precioNoSocio*$_SESSION['invitados']);

         $_SESSION['precioTotal']=$precioTotal;

         echo "El total a pagar seria ".$precioTotal."€";

    ?>
    <br>
    <!-- VOLVEMOS ATRAS SIN COMPRAR-->
    <form action="Alquiler_Usuario.php">
        <input type="submit" class="cambioCont" value="Cancelar">
    </form>
    <!-- VAMOS AL PHP EN EL QUE INTRODUCIREMOS LOS DATOS -->
    <form action="Introducir_Alquiler_Usuario.php">
        <input type="submit" class="comprar" value="Comprar">
    </form>
    <br>


 </div>

  <footer>
    <br>
    <div class="Terminos">
      <div class="Politica">
        <ul>
          <li>Política de privacidad</li>
          <li> | </li>
          <li>Política de cookies</li>
          <li> | </li>
          <li>Contactos</li>
        </ul>
      </div>
      
        <div class="contendorfooterlogo">
        <img src="SocialClub (2).svg" alt="Logo_Social_Club" class="footerlogo" />
      </div>
      <div class="Propietarios">
        © By Alejandro
      </div>
    </div>
  </footer>
  
</body>
</html>