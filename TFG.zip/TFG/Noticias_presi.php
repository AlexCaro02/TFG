<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesion</title>
    <link rel="stylesheet" href="Css.css" />
    <link href="fontawesome/css/all.css" rel="stylesheet" />
</head>

<body>
    <?php 
    session_start();
    include './Php/Conexion.php';
    ?>
    <div id="header">
        <div class="logito">
            <img src="SocialClub (2).svg" alt="Logo_Social_Club" class="logo" />
        </div>
        <nav>
            <a href="Principal_Presidente.php">Home</a>
            <a href="Noticias_presi.php">Noticias</a>
            <a href="Alquiler_Presi.php">Alquilar</a>
            <a href="PerfilPresi.php">Perfil</a>
            <div class="animation start-2"></div>
        </nav>
         <!-- DESTRUIMOS LA SESION -->
        <form action='destruir_sesion.php' class="Sesions">
            <label for="sesionDestroy" class="nombreUsuario"><?php echo $_SESSION['usuario']; ?></label>
            <input type="submit" name="sesionDestroy" value="CERRAR" class="cerraSesion" />
        </form>
    </div>
    <div id="cuerpoNoticiasPresi">

     <!-- CREAMOS NOTICIAS COMO PRESI-->

        <div class="TodoNoticias">
            <div>
                <h3 class="tituloCrearNoticias">Crear Noticias</h3>
            </div>
            <div>
                <form method='POST' action='crearNoticia.php' class="FormCrearNoticias">
                    <label for="fotoNotPresi">Dirección Foto :</label><input type='text' name='fotoNotPresi' id='fotoNotPresi'>
                    <br>
                    <label for="titNotPres">Titulo :</label><input type='text' name='titNotPres' id='titNotPres'>
                    <br> 
                    <label for="contNotPres">Contenido :</label>
                    <textarea name="contNotPres" id="contNotPres" cols="80" rows="10"></textarea>
                    <br>
                    <input type="submit" value="Crear noticia" id="alquilar">
                </form>
            </div>
        </div>
        <?php
 //MOSTRAMOS LAS NOTICIAS CON EL BOTON DE BORRARLAS
        $sql = "SELECT * FROM noticias ";
        $ejecuta_sentencia = mysqli_query($conn, $sql);

        while ($row = mysqli_fetch_array($ejecuta_sentencia)) {
            echo "<div id='Noticias'>
                      <div class='izqNoticias'>";
            echo    "<img src='" . $row['imagen'] . "' alt='Instalaciones' height='200px' width='200px'>";
            echo  "</div>
                      <div class='derNoticias'>";
            echo    "<p><b class='titNoticias'>" . $row['titulo'] . "</b></p><br>" . "<p class='contNoticias'>" . $row['contenido'] . "</p>";
            echo    "<p class='fechNoticias'>" . $row['fech_creacion'] . "</p>
                        </div>
                        <form method='POST' action='eliminarNoticia.php'>
                        <input style='display:none;' type='text' name='idNoticia' value='".$row['idNoticia']."'>
                        <input type='submit' class='ElimNoticia' value='eliminar'>
                        </form>
                      </div>";
            
        }

        ?>
       
        <br>
        <br>
        <br>

    </div>
    <footer>
        <br>
        <div class="Terminos">
            <div class="Politica">
                <ul>
                    <li>Política de privacidad</li>
                    <li> | </li>
                    <li>Política de cookies</li>
                    <li> | </li>
                    <li>Contactos</li>
                </ul>
            </div>
            <div class="contendorfooterlogo">
                <img src="SocialClub (2).svg" alt="Logo_Social_Club" class="footerlogo" />
            </div>
            <div class="Propietarios">
                © By Alejandro
            </div>
        </div>
    </footer>
</body>