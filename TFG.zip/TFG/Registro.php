<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <link rel="stylesheet" href="Css.css" />
    <link href="fontawesome/css/all.css" rel="stylesheet" />
</head>
<body> 
<?php

  include './Php/Conexion.php';

  //INICIALIZAMOS LAS VARIABLES

    $usuarioError = $dniError = $nombreError = $apellidoError = $numfamError = "";
    $usuario = $dni = $nombre = $apellido = $numfam = "";
    $correcto = "";

//HACEMOS COMPROBACIONES DE LOS DATOS INTRODUCIDOS Y CONTROLAMOS LOS ERRORES

    if($_SERVER["REQUEST_METHOD"] == "POST"){
      $cont = 0; 
      if(empty($_POST["usuario"])){
        $usuarioError = "El usuario no puede estar vacio"; 
        $cont++;
      }else{
        $regexp = '/^[a-z0-9]+$/i';
        $entrada = $_POST["usuario"];

        $resultado = preg_match($regexp, $entrada);
        if(!$resultado) {
          $usuarioError = "El usuario no puede contener caracteres extraños"; 
        }

        $resultado = preg_match($regexp, $entrada);
        if($resultado) {
          $usuario = validar_input($_POST["usuario"]);
        }
        
      }
      if(empty($_POST["dni"])){
        $dniError = "El dni no puede estar vacio";
        $cont++; 
      }else{
        $dni=$_POST["dni"];
        $letra = substr($dni, -1);
        $numeros = substr($dni, 0, -1);

        if(is_int(intval($numeros)) && is_string($letra)){
          if (substr("TRWAGMYFPDXBNJZSQVHLCKE", $numeros%23, 1) == $letra && strlen($letra) == 1 && strlen($numeros) == 8 ){
            $dni = validar_input($_POST["dni"]);
          }else{
            $dniError = "El dni debe ser correcto";
            $cont++; 
          }
          
        }else{
         
          $dniError = "El dni debe ser correcto";
            $cont++; 
        }
        


      }
      
        
      
      if(empty($_POST["nombre"])){
        $nombreError = "El nombre no puede estar vacio";
        $cont++; 
      }else{
        $nombre = validar_input($_POST["nombre"]);
      }
      if(empty($_POST["apellido"])){
        $apellidoError = "El apellido no puede estar vacio";
        $cont++; 
      }else{
        $apellido = validar_input($_POST["apellido"]);
      }
      if(empty($_POST["numfam"])){
        $numfamError = "El numfam no puede estar vacio";
        $cont++; 
      }else{
        $numfam = validar_input($_POST["numfam"]);
      }
      $q1 = mysqli_query($conn,"SELECT * FROM usuario WHERE usuario = '$usuario';");
      if(mysqli_num_rows($q1) == 0){
        $usuario = validar_input($_POST["usuario"]);
      }else{
        $usuarioError = "El usuario ya esta registrado, ingresa otro con otro nombre distinto";
        $cont++;
      }
      $q2 = mysqli_query($conn,"SELECT * FROM usuario WHERE dni = '$dni';");
      
      if(mysqli_num_rows($q2) == 0){
        $dni = validar_input($_POST["dni"]);
      }else{
        $dniError = "El dni ya esta registrado, ingresa otro con otro nombre distinto";
        $cont++;
      }
      //*****************  INSERTAR  ********************/
      if($cont == 0){
        $usuario = $_POST["usuario"];
        $dni = $_POST["dni"];
        $nombre = $_POST["nombre"];
        $apellido = $_POST["apellido"];
        $numfam = $_POST["numfam"];

        //QUERY INSERTAR CON TODOS LOS DATOS
        $sql = "INSERT INTO usuario (usuario,dni,nombre,apellidos,numFamiliares)
        VALUES ('$usuario','$dni','$nombre','$apellido','$numfam')";

        //COMPROBAR QUE EL INSERT SE HA REALIZADO CORRECTAMENTE Y INSERTAR
        if (mysqli_query($conn,$sql)) {
          $correcto = "<br> Registro creado correctamente";
          //UNA VEZ REGISTRADO SE BORRARAN Y APARECERA EL VALOR DEL PLACEHOLDER
          $_POST["usuario"] = "";
          $_POST["dni"] = "";
          $_POST["nombre"] = "";
          $_POST["apellido"] = "";
          $_POST["numfam"] = "";
        } else {
          $correcto = "<br> Error al insertar datos en la base de datos";
        }

        //CERRAR LA CONEXIÓN    
        mysqli_close($conn);
      }
    }

    function validar_input($data){
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }
?>
<div class="conjunto">
    <div id="header">
        <img src="SocialClub (2).svg" alt="Logo_Social_Club" class="logo" />
    </div>
    <div class="registro">
        <div id="secundario">
          <h1 class="titulo">Registrarte</h1>
          <div class="datos">
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) ?>">
              <div class="formulario">
                <input type="text" placeholder="Usuario"  name="usuario" value="<?php if (!empty($_POST["usuario"])) {
                                                                                        echo $usuario; 
                                                                                      }else{
                                                                                        echo "";
                                                                                      }
                                                                                ?>"/>
                <span class="error invalid-feedback"> <?php echo $usuarioError;?></span>
                <input type="text" placeholder="DNI"   name="dni" value="<?php if (!empty($_POST["dni"])) {
                                                                                        echo $dni; 
                                                                                      }else{
                                                                                        echo "";
                                                                                      }
                                                                                ?>"/>
                <span class="error invalid-feedback"> <?php echo $dniError;?></span>
                <input type="text" placeholder="Nombre"   name="nombre" value="<?php if (!empty($_POST["nombre"])) {
                                                                                        echo $nombre; 
                                                                                      }else{
                                                                                        echo "";
                                                                                      }
                                                                                ?>"/>
                <span class="error invalid-feedback"> <?php echo $nombreError;?></span>
                <input type="text" placeholder="Apellido"  name="apellido" value="<?php if (!empty($_POST["apellido"])) {
                                                                                        echo $apellido; 
                                                                                      }else{
                                                                                        echo "";
                                                                                      }
                                                                                ?>"/>
                <span class="error invalid-feedback"> <?php echo $apellidoError;?></span>
                <input type="number" placeholder="Num_Fam"  name="numfam" value="<?php if (!empty($_POST["num_fam"])) {
                                                                                        echo $numfam; 
                                                                                      }else{
                                                                                        echo "";
                                                                                      }
                                                                                ?>"/>
                <span class="error invalid-feedback"> <?php echo $numfamError;?></span>
                <input type="submit" id="botonreg" value="Registrar" name="botonreg"></input>
                <input type="reset" id="botonreseteo"name="reseteo" value="Resetear">
                <span class="correcto invalid-feedback"><?php echo $correcto;?></span>
              </div>
            </form>
          </div>
        </div>
    </div>
    <div class="botonatras">
    <button class="atras"><a href="Home.php">Atrás</a></button>
    </div>
</div>
    
</body>
</html>