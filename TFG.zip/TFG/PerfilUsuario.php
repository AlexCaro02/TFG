<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesion</title>
    <link rel="stylesheet" href="Css.css" />
    <link href="fontawesome/css/all.css" rel="stylesheet" />
</head>
<body>
<?php
session_start(); 
include './Php/Conexion.php';
        $errorActual=$_SESSION['errorOldPass'];
        $errorNueva=$_SESSION['errorNewPass'];
        $correcto=$_SESSION['passCreated'];
?>
    <div id="header">
        <div class="logito">
        <img src="SocialClub (2).svg" alt="Logo_Social_Club" class="logo" />
        </div>
        <nav>
            <a href="Principal_Usuario.php">Home</a>
            <a href="Noticias.php">Noticias</a>
            <a href="Alquiler_Usuario.php">Alquilar</a>
            <a href="PerfilUsuario.php">Perfil</a>
            <div class="animation start-4"></div>
        </nav>
         <!-- DESTRUIMOS LA SESION -->
        <form action='destruir_sesion.php' class="Sesions">
            <label for="sesionDestroy" class="nombreUsuario"><?php echo $_SESSION['usuario'];?></label>
            <input type="submit" name="sesionDestroy" value="CERRAR" class="cerraSesion"/>
        </form>
    </div>
    <div id="Perfil">
        <h1>Perfil de <?php echo $_SESSION['usuario'];?></h1>
        <div class="CPPerfil">

        <?php
 //MOSTRAMOS DATOS DEL USUARIO Y CAMBIOS DE CONTRASEÑA SIENDO VALIDAS Y LA NUEVA IGUALES SE ENVIARAN A CAMBIAR
          $user=$_SESSION['usuario'];
          $sql= "SELECT * FROM usuario WHERE usuario='".$user."'";
          $ejecuta_sentencia = mysqli_query($conn, $sql);

          while($row=mysqli_fetch_array($ejecuta_sentencia)) {                              
              echo " <div class='contenedorPerfil'>
              <p name='usuario'><label for='usuario'><b>Nombre de Usuario :</b></label> ".$row['usuario']."<p>
              <p name='apellidos'><label for='apellidos'><b>Apellidos :</b></label>".$row['apellidos']."</p>
              <p name='apellidos'><label for='usuario'><b>Dni :</b></label>".$row['dni']."</p>
              <p name='usuario'><label for='usuario'><b>Número de Familiares :</b></label>".$row['numFamiliares']."</p>";
          }

        ?>
        
            <form method="post" action='./Php/cambioContraseña.php' class="Sesions">
            <p name='oldPass'><label for='oldPass'><b>Introduzca la actual contraseña :</b></label> <input type="text" name="oldPass"><p>
            <span class="error invalid-feedback"> <?php echo $errorActual;?></span>
            <p name='newPass'><label for='newPass'><b>Introduzca la nueva contraseña :</b></label> <input type="text" name="newPass"><p>
            <p name='newPassConfirm'><label for='newPassConfirm'><b>Confirme la nueva contraseña :</b></label> <input type="text" name="newPassConfirm"><p>
            <span class="error invalid-feedback"> <?php echo $errorNueva;?></span>  
            <span class="valid-feedback"><?php echo $correcto;?></span>
          </div>

            <div class="BotonCambioCont">
              <input type="submit" name="sesionDestroy" value="Cambiar contraseña" class="cambioCont"/>
            </div>
            </form>
        </div>
    </div>
    <footer>
      <br>
      <div class="Terminos">
        <div class="Politica">
            <ul>
              <li>Política de privacidad</li>
              <li> | </li>
              <li>Política de cookies</li>
              <li> | </li>
              <li>Contactos</li>
            </ul>
        </div>
        <div class="contendorfooterlogo">
          <img src="SocialClub (2).svg" alt="Logo_Social_Club" class="footerlogo" />
        </div>
        <div class="Propietarios">
          © By Alejandro
        </div>
      </div>
    </footer>
</body>

<?php
$_SESSION['errorOldPass']="";
$_SESSION['errorNewPass']="";
$_SESSION['passCreated']="";
?>