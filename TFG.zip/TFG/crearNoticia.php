<?php
include './Php/Conexion.php';
//PILLAMOS LOS DATOS DEL POST
$titulo=$_POST["titNotPres"];
$contenido=$_POST["contNotPres"];
$imagen=$_POST["fotoNotPresi"];
$fech_creacion= date('d/m/Y');

//CREAMOS LA SENTENCIA SQL 
$sql = "INSERT INTO noticias (titulo,contenido,imagen,fech_creacion)
        VALUES ('$titulo','$contenido','$imagen','$fech_creacion')";

        //COMPROBAR QUE EL INSERT SE HA REALIZADO CORRECTAMENTE Y INSERTAR
        if (mysqli_query($conn,$sql)) {
          $correcto = "<br> Registro creado correctamente";
            $_POST["fotoNotPresi"] = "";
            $_POST["titNotPres"] = "";
            $_POST["contNotPres"] = "";
            $_POST["fechNotPres"] = "";
          header('Location: Noticias_presi.php');


          
        } else {
          $correcto = "<br> Error al insertar datos en la base de datos";
        }




?>