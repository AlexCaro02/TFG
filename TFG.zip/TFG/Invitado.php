<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesion</title>
    <link rel="stylesheet" href="Css.css" />
    <link href="fontawesome/css/all.css" rel="stylesheet" />
</head> 
<body>
<?php
session_start();
include './Php/Conexion.php';
?>
    <div id="header">
        <div class="logito">
        <img src="SocialClub (2).svg" alt="Logo_Social_Club" class="logo" />
        </div>
       
    </div>
    <div id="cuerpoNoticias">
    
<!--SOLO CARGAMOS LAS NOTICIAS PARA LOS INVITADOS-->
      <?php

            $sql= "SELECT * FROM noticias ";
            $ejecuta_sentencia = mysqli_query($conn, $sql);

            while($row=mysqli_fetch_array($ejecuta_sentencia)) {                              
                echo"<div id='Noticias'>
                      <div class='izqNoticias'>";
                echo    "<img src='".$row['imagen']."' alt='Instalaciones' height='200px' width='200px'>";
                echo  "</div>
                      <div class='derNoticias'>";
                echo    "<p><b class='titNoticias'>".$row['titulo']."</b></p><br>"."<p class='contNoticias'>".$row['contenido']."</p>";
                echo    "<p class='fechNoticias'>".$row['fech_creacion']."</p>
                        </div>
                      </div>";
            }

      ?>
    <div class="contenedor_botones_principal">
            <div class="contenedor_botones">
              <button id="boton1" onclick="location.href='Home.php'">Volver</button>
              
            </div>
            
          </div>
      <br>
      <br>
      <br>
    
    </div>
    <footer>
      <br>
      <div class="Terminos">
        <div class="Politica">
            <ul>
              <li>Política de privacidad</li>
              <li> | </li>
              <li>Política de cookies</li>
              <li> | </li>
              <li>Contactos</li>
            </ul>
        </div>
        <div class="contendorfooterlogo">
          <img src="SocialClub (2).svg" alt="Logo_Social_Club" class="footerlogo" />
        </div>
        <div class="Propietarios">
          © By Alejandro
        </div>
      </div>
    </footer>
</body>