<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesion</title>
    <link rel="stylesheet" href="Css.css" />
    <link href="fontawesome/css/all.css" rel="stylesheet" />
</head>
<body>
<?php
session_start(); 
?>
    <div id="header">
        <div class="logito">
        <img src="SocialClub (2).svg" alt="Logo_Social_Club" class="logo" />
        </div>
        <nav>
            <a href="Principal_Admin.php">Home</a>
            <a href="Noticias_admin.php">Noticias</a>
            <a href="Facturas_Admin.php">Facturas</a>
            <a href="Socios_Admin.php">Socios</a>
            <div class="animation start-1"></div>
        </nav>
        <!-- DESTRUIMOS LA SESION -->
        <form action='destruir_sesion.php' class="Sesions">
            <label for="sesionDestroy" class="nombreUsuario"><?php echo $_SESSION['usuario'];?></label>
            <input type="submit" name="sesionDestroy" value="CERRAR" class="cerraSesion"/>
        </form>
    </div>
    <!-- ESTO ES SOLO UN MENU CON UN INICIO-->
    <div id="cuerpo">
      <div class="parteIzq">
        <div class="parteArrib">
            <div>
              <img src="./fotos/Somos.jpg" alt="Instalaciones" height="100%" width="80%">
            </div>
            <div>
              <p><b>¿Quienes somos?</b><br>
                SocialClub es la mayor compañia de ocio,que ofrece a los clientes <br>
                las mejores condiciones y ambientes en los que poder disfrutar.<br>
                A escala mundial,somos el primer club social en alcanzar 1 millón de clientes.
              </p>
            </div>
        </div>
        <div class="parteAbaj">
            <div>
              <p><b>¿Donde estamos?</b><br>
              Calle begoña, Calle Begonia, 2, numero 2, 41927 <br> Mairena del Aljarafe, Sevilla</p>
            </div>
            <div>
            <iframe class="iframe1" src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d7542.190650453071!2d-6.063472407427253!3d37.363797847820706!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1szaudin!5e0!3m2!1ses!2ses!4v1643824539536!5m2!1ses!2ses" width="400" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
            </div>
        </div>
      </div>
      <div class="parteDer">
        <div id="slider">
            <figure>
              <img src="./fotos/1.jpg" alt="Pista de tenis" height="10%" width="10%">
              <img src="./fotos/2.jpg" alt="Barcacoa" height="10%" width="10%">
              <img src="./fotos/3.jpg" alt="Pista de futbol sala" height="10%" width="10%">
              <img src="./fotos/4.jpg" alt="Pista de padel" height="10%" width="10%">
            </figure>
        </div>
      </div>
    </div>
    <footer>
      <br>
      <div class="Terminos">
        <div class="Politica">
            <ul>
              <li>Política de privacidad</li>
              <li> | </li>
              <li>Política de cookies</li>
              <li> | </li>
              <li>Contactos</li>
            </ul>
        </div>
        <div class="contendorfooterlogo">
          <img src="SocialClub (2).svg" alt="Logo_Social_Club" class="footerlogo" />
        </div>
        <div class="Propietarios">
          © By Alejandro
        </div>
      </div>
    </footer>
</body>