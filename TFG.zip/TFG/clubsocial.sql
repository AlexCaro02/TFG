-- phpMyAdmin SQL Dump
-- version 4.8.5 
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 15-02-2022 a las 23:48:03
-- Versión del servidor: 10.1.38-MariaDB
-- Versión de PHP: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `clubsocial`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alquiler`
--

CREATE TABLE `alquiler` (
  `idAlquiler` int(11) NOT NULL,
  `idServicio` int(11) NOT NULL,
  `idSocio` int(11) NOT NULL,
  `fecha` varchar(20) COLLATE utf8mb4_spanish_ci NOT NULL,
  `horas` varchar(20) COLLATE utf8mb4_spanish_ci NOT NULL,
  `personaSocio` int(11) NOT NULL,
  `personaNoSocio` int(11) NOT NULL,
  `precio` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `alquiler`
--

INSERT INTO `alquiler` (`idAlquiler`, `idServicio`, `idSocio`, `fecha`, `horas`, `personaSocio`, `personaNoSocio`, `precio`) VALUES
(11, 1, 23, '6 , febrero ,2022', '11:00 / 13:00', 2, 2, 22);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `noticias`
--

CREATE TABLE `noticias` (
  `idNoticia` int(11) NOT NULL,
  `titulo` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `contenido` varchar(2500) COLLATE utf8mb4_spanish_ci NOT NULL,
  `imagen` varchar(1500) COLLATE utf8mb4_spanish_ci NOT NULL,
  `fech_creacion` varchar(20) COLLATE utf8mb4_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `noticias`
--

INSERT INTO `noticias` (`idNoticia`, `titulo`, `contenido`, `imagen`, `fech_creacion`) VALUES
(10, 'El Psoe gana', 'MÃ¡s que unas elecciones autonÃ³micas, las de Castilla y LeÃ³n, a ratos, han parecido unas generales. Era de esperar que los resultados electorales se leyesen en clave nacional despuÃ©s de que los partidos y todos sus lÃ­deres se hayan volcado en estos comicios, donde unos se jugaban mÃ¡s que otros y, sobre todo, unos arriesgaron mÃ¡s que otros. El resultado de las urnas no da lugar a demasiadas combinaciones y solo hay una posible suma que supera la mayorÃ­a absoluta de 41 procuradores necesarios para la investidura y la formaciÃ³n de gobierno. Solo PP (con sus 31 procuradores) y Vox (con 13) pueden ir juntos hacia la gobernabilidad de Castilla y LeÃ³n, asÃ­ que todas las miradas estÃ¡n puestas en estas dos formaciones que estÃ¡n condenadas a entenderse. PP quiere seguir gobernando en uno de sus principales bastiones nacionales, pero la convocatoria electoral solo le ha servido para cambiar de socio, de Ciudadanos a Vox, y estos ya lo han avisado durante las Ãºltimas semanas: no darÃ¡n \"gratis\" sus votos.', 'https://img2.rtve.es/i/?w=1600&i=1644155816642.jpg', '15/02/2020');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `servicios`
--

CREATE TABLE `servicios` (
  `idServicio` int(11) NOT NULL,
  `servicio` varchar(20) COLLATE utf8mb4_spanish_ci NOT NULL,
  `precio_socio` double NOT NULL,
  `precio_no_socio` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `servicios`
--

INSERT INTO `servicios` (`idServicio`, `servicio`, `precio_socio`, `precio_no_socio`) VALUES
(1, 'Barbacoa', 5, 6),
(2, 'Pista de Tenis 1', 1, 2.6),
(3, 'Pista de Tenis 2', 1, 2.4),
(4, 'Pista de Padel 1', 1, 2.5),
(5, 'Pista de Padel 2', 1, 2.4),
(6, 'Pista de Futbol', 5, 6),
(7, 'Pista de Baloncesto', 3, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `idSocio` int(11) NOT NULL,
  `usuario` varchar(20) COLLATE utf8mb4_spanish_ci NOT NULL,
  `password` varchar(20) COLLATE utf8mb4_spanish_ci NOT NULL,
  `dni` varchar(20) COLLATE utf8mb4_spanish_ci NOT NULL,
  `nombre` varchar(20) COLLATE utf8mb4_spanish_ci NOT NULL,
  `apellidos` varchar(20) COLLATE utf8mb4_spanish_ci NOT NULL,
  `numFamiliares` int(11) NOT NULL,
  `presidente` tinyint(1) NOT NULL,
  `admin` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`idSocio`, `usuario`, `password`, `dni`, `nombre`, `apellidos`, `numFamiliares`, `presidente`, `admin`) VALUES
(1, 'admin', 'admin', '', '', '', 0, 0, 1),
(16, 'presi', 'presi', '31871015F', 'presidente', 'sanchez', 3, 1, 0),
(23, 'ale', 'ale', '73575474S', 'alejandro', 'caro verde', 8, 0, 0);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alquiler`
--
ALTER TABLE `alquiler`
  ADD PRIMARY KEY (`idAlquiler`);

--
-- Indices de la tabla `noticias`
--
ALTER TABLE `noticias`
  ADD PRIMARY KEY (`idNoticia`);

--
-- Indices de la tabla `servicios`
--
ALTER TABLE `servicios`
  ADD PRIMARY KEY (`idServicio`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`idSocio`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `alquiler`
--
ALTER TABLE `alquiler`
  MODIFY `idAlquiler` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `noticias`
--
ALTER TABLE `noticias`
  MODIFY `idNoticia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `idSocio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
