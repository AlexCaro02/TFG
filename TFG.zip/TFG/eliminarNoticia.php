<?php
//Conexion con la base
include './Php/Conexion.php';
 
//Creamos la sentencia SQL y la ejecutamos
$sql="Delete From noticias Where idNoticia='".$_POST["idNoticia"]."'";
//COMPROBAR QUE EL DELETE SE HA REALIZADO CORRECTAMENTE Y INSERTAR
if (mysqli_query($conn,$sql)) {
    echo "<br> Registro Borrado correctamente";
    header('Location: Noticias_presi.php');
} else {
    echo "<br> Error al borrar datos en la base de datos";
}

//CERRAR LA CONEXIÓN    
mysqli_close($conn);


?>