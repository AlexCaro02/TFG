<!DOCTYPE html>
<html lang="en">
<head> 
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesion</title>
    <link rel="stylesheet" href="Css.css" />
    <link href="fontawesome/css/all.css" rel="stylesheet" />
</head>
<body>
<?php
session_start();
include './Php/Conexion.php';
?>
    <div id="header">
        <div class="logito">
        <img src="SocialClub (2).svg" alt="Logo_Social_Club" class="logo" />
        </div>
        <nav>
            <a href="Principal_Admin.php">Home</a>
            <a href="Noticias_admin.php">Noticias</a>
            <a href="Facturas_Admin.php">Facturas</a>
            <a href="Socios_Admin.php">Socios</a>
            <div class="animation start-3"></div>
        </nav>

        <!-- DESTRUIMOS LA SESION -->
        <form action='destruir_sesion.php' class="Sesions">
            <label for="sesionDestroy" class="nombreUsuario"><?php echo $_SESSION['usuario'];?></label>
            <input type="submit" name="sesionDestroy" value="CERRAR" class="cerraSesion"/>
        </form>
    </div>

    <table class="container">
            <tr>
                <th>Usuario</th>
                <th>DNI</th>
                <th>Generar Factura</th>
                
                <?php
                          //GENERAMOS UNA TABLA CON LOS USUARIOS PARA HACERLES LAS FACTURAS
                        $sql= "SELECT * FROM usuario WHERE usuario <> 'admin'";
                        $ejecuta_sentencia = mysqli_query($conn, $sql);

                        while($row=mysqli_fetch_array($ejecuta_sentencia)) {                              
                            echo"<tr>";
                            echo"<td>".$row['usuario']."</td>";
                            echo"<td>".$row['dni']."</td>";

                            
                              //MANDAMOS EL ID DEL USUARIO SELECCIONADO PARA FORMAR SU FACTURA
                            echo"<td><form method='POST' action='Generar_Factura.php'><input type='hidden' name='hidden1' value='".$row['idSocio']."'/>
                                                                                    <input type='submit' value='Generar'/></form></td>";
                            
                            echo"</tr>";
                        }

                    ?>

            <tr>
        </table>
    
    <footer>
      <br>
      <div class="Terminos">
        <div class="Politica">
            <ul>
              <li>Política de privacidad</li>
              <li> | </li>
              <li>Política de cookies</li>
              <li> | </li>
              <li>Contactos</li>
            </ul>
        </div>
        <div class="contendorfooterlogo">
          <img src="SocialClub (2).svg" alt="Logo_Social_Club" class="footerlogo" />
        </div>
        <div class="Propietarios">
          © By Alejandro
        </div>
      </div>
    </footer>
</body>
